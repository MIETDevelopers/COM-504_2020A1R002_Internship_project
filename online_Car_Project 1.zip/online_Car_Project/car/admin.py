from django.contrib import admin
from .models import *

# Register your models here.
admin.site.register(Add_Car)
admin.site.register(Categary)
admin.site.register(Customer)
admin.site.register(About)
admin.site.register(Contact)
